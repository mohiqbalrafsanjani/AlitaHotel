<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class WelcomeTIKU extends CI_Controller {
	public function __construct()
	{
		parent::__construct();

		// load Session Library
		$this->load->library('session');
			
		// load url helper
		$this->load->helper('url');

		$this->load->model('mymodel');
		//memanggil applications/models/Mymodel.php
		
	}


	public function index()
	{
		$this->db->select('*')->from('film'); 
		//ambil semua data dari tabel film 
		$this->db->order_by("tanggal_rilis", "desc");
		//dengan urutan tanggal_rilis paling terbaru 
		$this->db->limit(3);  
		//dan hanya 3 baris saja
		$data = $this->db->get()->result_array();  
		$data = array('data' => $data);
		//masukkan hasil query ke array data
		$this->load->view('home', $data);
		//masukkan array data ketika menampilkan home
	}

	public function pesan()
	{
		$id_film= $_POST['id_film'];	

		//mengambil id_film dari halaman sebelumnya
		$data['film'] = $this->mymodel->GetWhere('film', array('id_film' => $id_film)); 
		
		//SESSION
		$judul = $data['film'][0]['judul'];
		$this->session->set_userdata('judul', $judul);
		$this->session->set_userdata('id_film', $id_film);
		
		$data['jadwal'] = $this->mymodel->Get('jadwal');
		//ambil semua data dari tabel jadwal 
		
		$data = array('data' => $data);
		$this->load->view('pesan', $data);
		//masukkan array data ketika menampilkan pesan
	}

	public function tentang_kami()
	{
		$this->load->view('tentang_kami');
	}
	
	public function pesan_kursi()
	{
		$this->load->model('mymodel');

		$tanggal_nonton = $_POST['tanggal_nonton'];
		$id_jadwal = $_POST['jadwal'];
		$this->session->set_userdata('tanggal_nonton', $tanggal_nonton);
		$this->session->set_userdata('id_jadwal', $id_jadwal);

		$data['jadwal'] = $this->mymodel->GetWhere('jadwal', array('id_jadwal' => $id_jadwal));
		//ambil semua data dari tabel jadwal yang id_jadwal nya = id_jadwal dari halaman sebelumnya 

		//SESSION
		$jadwal = $data['jadwal'][0]['jadwal'];
		$this->session->set_userdata('jadwal', $jadwal);

		$data['kursi'] = $this->mymodel->Get('kursi');
		//ambil semua data dari tabel kursi 

		$id_film = $this->session->userdata('id_film');
		$query_kursi_booked = $this->db->query('SELECT nokur FROM pesanan where id_film = "'.$id_film.'" and id_jadwal="'.$id_jadwal.'" and tanggal_nonton="'.$tanggal_nonton.'"');
		
		$data['kursi_booked'] = $query_kursi_booked->result_array();
		
		$data = array('data' => $data);
		
		$this->load->view('pesan_kursi', $data);
		//masukkan array data ketika menampilkan pesan_kursi
	}

	public function pesanan()
	{
		if(!empty($_POST['pilihKursi'])){
			//jika memilih kursi, maka isi $data['kursi']
			
			$kursi = $_POST['pilihKursi'];
			$this->session->set_userdata('kursi', $kursi);
			$data['kursi'] = $kursi;
			
		}	
		else{
			//jika tidak memilih kursi, maka $data['kursi'] kosong
			$data['kursi']=[];
		}
		$data = array('data' => $data);
		$this->load->view('pesanan', $data);
	}

	public function hapusKursi($no){  
		$listkursi = $this->session->userdata('kursi');
	
		unset($listkursi[$no]); 
		//hapus array index $no
		$data['kursi'] = array_values($listkursi);
		//mengurutkan index

		$kursi = $data['kursi'];
		//set lagi
		$this->session->set_userdata('kursi', $kursi);
		
		$data = array('data' => $data);
		$this->load->view('pesanan',$data); 
	}
		
	public function edit()
	{
		$listkursi = $this->session->userdata('kursi');
		$kursi = array_values($listkursi);
		//mengurutkan index
		
		$id_film = $this->session->userdata('id_film');
		$id_jadwal = $this->session->userdata('id_jadwal');
		$tanggal_nonton = $this->session->userdata('tanggal_nonton');
		
		$this->load->model('mymodel');
		$data['film'] = $this->mymodel->GetWhere('film', array('id_film' => $id_film)); 

		$data['kursi_checked']= $kursi;

		$data['kursi'] = $this->mymodel->Get('kursi');

		$query_kursi_booked = $this->db->query('SELECT nokur FROM pesanan where id_film = "'.$id_film.'" and id_jadwal="'.$id_jadwal.'" and tanggal_nonton="'.$tanggal_nonton.'"');
		$data['kursi_booked'] = $query_kursi_booked->result_array();

		$data = array('data' => $data);
		$this->load->view('edit', $data);
	}
	
	public function bayar()
	{
		$listkursi = $this->session->userdata('kursi');
		$data['kursi'] = array_values($listkursi);

		$jum_kursi = count($data['kursi']);
		$j=0;
		$this->load->model('mymodel');
		foreach($data['kursi'] as $k){
			$data_insert = array(
				'id_film' => $this->session->userdata('id_film'),
				'tanggal_nonton' => $this->session->userdata('tanggal_nonton'),
				'id_jadwal' => $this->session->userdata('id_jadwal'),
				'nokur' => $k
			);		
			if($this->mymodel->Insert('pesanan', $data_insert)){
				$j++;
				//jika berhasil insert tambah +1 nilai pada $j
			}		
		}
		$data = array('data' => $data);
		if($j==$jum_kursi){
			//misal pesan 2 kursi
			//jika berhasil insert 2 kursi, maka tampilkan tiket
			$this->load->view('tiket', $data);
		}
		else{
			//jika tidak, maka kembali ke pemesanan
			$this->load->view('pesanan',$data);
		}
		
	}
}

