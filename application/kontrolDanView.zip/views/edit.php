<?php 
    $this->load->view('header');
?>
    <br>
    <br>
    <br><h2 align="center">Edit Kursi</h2><br>
    <div class="container"> <!--container-->
    <form id="pesan" class="form-horizontal" method="post" action="<?php echo base_url(); ?>index.php/WelcomeTIKU/pesanan">
        <div class="row"> <!--row-->
            <div class="col-2">
                <b>Film</b>
            </div> <!--col-2-->
            <div class="col-10">
                <?php echo $this->session->userdata("judul"); ?>
            </div> <!--col-10-->
        </div> <!--row-->
        <br>
        <div class="row"> <!--row-->
            <div class="col-2">
                <b>Tanggal/ Jadwal</b>
            </div> <!--col-2-->
            <div class="col-10">
                <?php $tn=$this->session->userdata("tanggal_nonton"); 
                echo date('l', strtotime($tn)).", ".$tn."/ ".$this->session->userdata("tanggal_nonton"); ?> 
            </div> <!--col-10-->
        </div> <!--row-->
        <br>
        <div class="row"> <!--row-->
            <div class="col-2"> <!--col-2-->
                <b>Tempat Duduk</b>
            </div> <!--col-2-->
            <div class="col-10"> <!--col-10-->
            <div class="seatStructure txt-center" >
                <table id="seatsBlock">
                    <tr>
                        <td></td>
                        <td>1</td>
                        <td>2</td>
                        <td>3</td>
                        <td>4</td>
                    </tr>
                    <tr>
                        <?php
                            $k=0;
                            for ($i='A'; $i<='E'; $i++){   ?>    
                                <tr>
                                    <td><?php echo $i; ?></td>
                                    <?php for($j=1; $j<=4; $j++){ 
                                        $ij=$data['kursi'][$k]['nokur'];?>
                                    <td>
                                        <input name="pilihKursi[]" type="checkbox" class="seats" value="<?php echo $ij; ?>" 
                                        <?php //if($i.$j=="A1"|| $i.$j=="A2" || $i.$j=="A3"){echo "checked";}?> 
                                        <?php //if($i.$j=="C1"|| $i.$j=="C2" || $i.$j=="C3"){echo "disabled";}?>
                                        <?php foreach($data['kursi_checked'] as $kursi){ 
                                            if($ij==$kursi)
                                                echo "checked";
                                        }
                                        for ($x=0; $x<count($data['kursi_booked']); $x++){
                                            if($ij==$data['kursi_booked'][$x]['nokur'])
                                                echo "disabled";
                                        }
                                        ?>
                                        <?php ?>
                                        >
                                    </td>
                                    <?php $k++;} ?>
                                </tr>
                            <?php } ?>
                        </tr>                
                </table>
                </div> <!--seatStructure-->  
            </div> <!--col-10-->
        </div> <!--row-->
        <br>
        <div class="row"> <!--row-->
            <div class="col-2"> <!--col-2-->
            </div> <!--col-2-->
            <div class="col-10"> <!--col-10-->
                Harga Rp 60.000,00/ tiket<br><br>
                <button class="btn btn-primary" type="submit">Submit</button>
            </div> <!--col-10-->
        </div> <!--row-->
        </form>
    </div> <!--container-->
    <br>
<?php 
    $this->load->view('footer');
?>