<?php 
    $this->load->view('header');
?>
    <br>
    <br>
    <br><h2 align="center">Pesan Tiket Film</h2><br>
    <div class="container"> <!--container-->
    <form id="pesan" class="form-horizontal" method="post" action="<?php echo base_url(); ?>index.php/WelcomeTIKU/pesan_kursi">
        <div class="card mb-3">
            <div class="row no-gutters">
                <div class="col-md-2">
                <img src="<?php echo base_url(); ?>assets/images/<?php echo $data['film'][0]['foto']; ?>" class="card-img" alt="<?php echo $data['film'][0]['foto']; ?>">
                </div>
                <div class="col-md-10">
                <div class="card-body">
                    <h5 class="card-title"><?php echo $data['film'][0]['judul']; ?></h5>
                    <p class="card-text"><?php echo $data['film'][0]['sinopsis']; ?></p>
                    <p class="card-text"><small class="text-muted"><?php echo $data['film'][0]['keterangan']; ?></small></p> 
                </div>
                </div>
            </div>
        </div>
        <div class="row"> <!--row-->
            <div class="col-2">
                <b>Tanggal</b>
            </div> <!--col-2-->
            <div class="col-10">
                <input type="date" name="tanggal_nonton" required>
            </div> <!--col-10-->
        </div> <!--row-->
        <br>
        <div class="row"> <!--row-->
            <div class="col-2">
                <b>Jadwal</b>
            </div> <!--col-2-->
            <div class="col-10">
                <?php $no=1; 
                foreach ($data['jadwal'] as $jdw){ ?>
                <div class="custom-control custom-radio custom-control-inline">
                    <input type="radio" id="customRadioInline<?php echo $no; ?>" name="jadwal" class="custom-control-input" value="<?php echo $jdw['id_jadwal']; ?>" required>
                    <label class="custom-control-label" for="customRadioInline<?php echo $no; ?>"><?php echo $jdw['jadwal']; ?></label>
                </div>
                <?php $no++;} ?>
                <!-- <div class="custom-control custom-radio custom-control-inline">
                    <input type="radio" id="customRadioInline2" name="jadwal" class="custom-control-input" value="sore">
                    <label class="custom-control-label" for="customRadioInline2">Sore</label>
                </div> -->
            </div> <!--col-10-->
        </div> <!--row-->
        <br>
        <div class="row"> <!--row-->
            <div class="col-2"> <!--col-2-->
            </div> <!--col-2-->
            <div class="col-10"> <!--col-10-->
                <button class="btn btn-primary" type="submit">Submit</button>
            </div> <!--col-10-->
        </div> <!--row-->
        </form>
    </div> <!--container-->
    <br><br><br>
<?php 
    $this->load->view('footer');
?>