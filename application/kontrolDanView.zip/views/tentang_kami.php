<?php 
    $this->load->view('header');
?>
    <br><br><br>
    <div class="container"> <!--container-->
        <div class="card bg-dark text-white">
            <img src="<?php echo base_url(); ?>assets/images/udinus.jpg" class="card-img" alt="Udinus">
            <div class="card-img-overlay">
                <h5 class="card-title">Kami adalah</h5>
                <p class="card-text">Mahasiswa BK UDINUS 2019.</p>
                <p class="card-text">Terima kasih telah berkunjung di Tiket Bioskop Kampus UDINUS (TIKU).</p>
            </div>
        </div> <!--card bg-dark text-white-->
    </div> <!--container-->
    <br>
<?php 
    $this->load->view('footer');
?>