    <footer class="footer mt-auto py-3" style="background-color: #007bff; color:#fff; text-align: center;">
        <div class="container">
            <span>Tiket Bioskop Kampus UDINUS (TIKU) &copy; BK 2019 with &#9829;</span>
        </div>
    </footer>
    <!-- Menyisipkan JQuery dan Javascript Bootstrap -->
    <!-- Urutan: JQuery, library js lain, terakhir Javascript Bootstrap -->
    <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery-3.3.1.slim.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/popper.min.js"></script>
    <script type="text/javascript"src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>

    
</body>
</html>